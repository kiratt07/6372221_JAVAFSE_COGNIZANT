public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileUser = new MobileApp("Alice");
        Observer webDashboard = new WebApp("AdminPanel");

        stockMarket.register(mobileUser);
        stockMarket.register(webDashboard);

        stockMarket.setPrice(123.45);
        System.out.println();

        stockMarket.setPrice(127.80);
        System.out.println();

        stockMarket.deregister(webDashboard);
        stockMarket.setPrice(130.25);
    }
}
