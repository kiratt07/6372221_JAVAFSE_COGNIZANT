public class WebApp implements Observer {
    private String dashboard;

    public WebApp(String dashboard) {
        this.dashboard = dashboard;
    }

    public void update(double price) {
        System.out.println("WebApp [" + dashboard + "]: Stock price updated to ₹" + price);
    }
}
