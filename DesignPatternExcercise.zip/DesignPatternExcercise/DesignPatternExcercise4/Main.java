public class Main {
    public static void main(String[] args) {
        PaymentProcessor paypal = new PayPalAdapter();
        PaymentProcessor stripe = new StripeAdapter();

        System.out.println("Processing payments through adapters:");
        paypal.processPayment(999.99);
        stripe.processPayment(499.50);
    }
}

