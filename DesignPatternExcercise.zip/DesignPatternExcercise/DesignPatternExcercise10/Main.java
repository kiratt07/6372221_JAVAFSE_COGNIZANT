public class Main {
    public static void main(String[] args) {

        Student student = new Student("Kirat", "238", "A");

        StudentView view = new StudentView();

        StudentController controller = new StudentController(student, view);

        controller.updateView();

        System.out.println();

        controller.setStudentName("Rohan");
        controller.setStudentId("323");  // 👈 Set new ID here
        controller.setStudentGrade("A");

        controller.updateView();
    }
}
