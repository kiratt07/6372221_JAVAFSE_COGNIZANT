public class Main {
    public static void main(String[] args) {
        CustomerRepository repository = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repository);

        service.printCustomerDetails("238");
        System.out.println();
        service.printCustomerDetails("323"); 
    }
}
