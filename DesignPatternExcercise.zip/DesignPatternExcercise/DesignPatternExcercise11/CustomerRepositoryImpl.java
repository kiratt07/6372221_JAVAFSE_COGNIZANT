import java.util.HashMap;
import java.util.Map;

public class CustomerRepositoryImpl implements CustomerRepository {
    private Map<String, Customer> customers = new HashMap<>();

    public CustomerRepositoryImpl() {
       
        customers.put("238", new Customer("238", "Kirat"));
        customers.put("323", new Customer("323", "Rohan"));
    }

    public Customer findCustomerById(String id) {
        return customers.get(id);
    }
}
